package com.example.databazeencryption;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    EditText emailaddress,password1;
    private ProgressDialog md;
    Button login1;
    TextView registeraccount;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailaddress=findViewById(R.id.emailaddress);
        password1=findViewById(R.id.paswword1);
        login1=findViewById(R.id.login1);
        registeraccount=findViewById(R.id.registeraccount);
        firebaseAuth = FirebaseAuth.getInstance();
        md = new ProgressDialog(this);

        login1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(emailaddress.getText().toString().isEmpty())
                {
                    emailaddress.setError("Required");
                    return;
                }
                if (password1.getText().toString().isEmpty()){
                    password1.setError("Required");
                    return;

                }
                md.setMessage("PROCESSING");
                md.show();
                firebaseAuth.signInWithEmailAndPassword(emailaddress.getText().toString().trim(),password1.getText().toString().trim()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())

                        {
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            startActivity(new Intent(getApplicationContext(), VerificationActivity.class));
                            emailaddress.setText("");
                            password1.setText("");
                            md.dismiss();
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"Please Try Again ",Toast.LENGTH_SHORT).show();
                            md.dismiss();


                        }

                    }
                });


            }
        });

        registeraccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),RegisterActivity.class));
            }
        });

    }
}